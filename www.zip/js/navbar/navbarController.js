var app = angular.module('cs');

app.controller('NavbarController', function($scope) {
  
});