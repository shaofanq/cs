var app = angular.module('cs');

app.controller('DashboardController', function($scope) {

});